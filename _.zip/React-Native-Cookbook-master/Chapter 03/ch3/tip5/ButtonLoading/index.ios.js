/**
 * Animating a button for a loading action
 * @author Crysfel Villa
 * @flow
 */

import React from 'react';
import { AppRegistry } from 'react-native';
import MainApp from './src/MainApp';

AppRegistry.registerComponent('ButtonLoading', () => MainApp);
